# MINT-Documentation
Markdown documentation for MINT
