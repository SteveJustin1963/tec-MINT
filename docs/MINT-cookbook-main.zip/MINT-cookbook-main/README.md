# MINT-cookbook

A place for small projects, tips and recipes related to MINT programming on the TEC-1

- Recipe 1: [8 LED light chaser](01-8-LED-light-chaser)
- Recipe 2: [4 digit counter](02-4-digit-counter)
- Recipe 3: [6 digit display buffer](03-6-digit-display-buffer)

Also a [MINT tutorial](mint-tutorial.md)
